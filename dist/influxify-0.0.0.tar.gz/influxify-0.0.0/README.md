# `influxify`

The `influxify` is a python package that can be used to convert any csv data to influxdb line protocol.

## Install & Usage

You can install `influxify` as follows:

```
pip install --index-url https://test.pypi.org/simple/ --no-deps influxify
```

Try to have fun with `influxify`
